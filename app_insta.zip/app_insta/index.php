<?php
session_start();
if(!isset($_SESSION['login'])){
  header("location:login.php?pesan=login dahulu");
}
include "koneksi.php";
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>    <style>
        body{
         background-color: darkgrey;
        }
        .card-img-top {
            transition: transform 0.3s;
        }
        .card-img-top:hover {
            transform: scale(1.1);
        }
    </style>
    <title>Zaenal Shoes</title>
   <link rel="icon" href="zaenaldian.png">
</head>
<body>
 
<div class="responsive">
<nav class="navbar navbar-expand-lg navbar-white bg-dark fixed-top">
  <div class="container-fluid">
    <img src="zaenalgg.png" alt="" width="150" height="50">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
       
    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
      <!-- Just an image -->
<nav class="navbar navbar-light bg-light">
  
</nav>
      <!-- Button trigger modal -->

      <span>
<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">
  +
</button>
<a href="logout.php"><button class="btn btn-secondary "><i class="bi bi-box-arrow-right"></i></button></a>
      </span>
 
    </div>
  </div>
</nav>    <br><br> <br> <br> <br>

    <div class="container">
    <div class="row justify-content-center">
        <?php while($post = mysqli_fetch_assoc($query)) { ?>
          <center>
            <div class="card" style="width: 30rem;">
  <img src="images/<?= $post['foto']?>" class="card-img-top" widht="200" height="400" alt="...">
  <div class="card-body">
    <p class="card-text"><?= $post['caption']?></p>
    <h5 class="card-text">
    <i class="bi bi-pin-map"></i> <?= $post['lokasi'] ?>
    </h5>
    <style>
                              .card-text {
    text-align: left; /* Teks rata kiri */
}

.card-text::before {
    content: ""; /* Membuat garis transparan */
    display: block;
    height: 1px;
    background-color: rgba(0, 0, 0, 0.1); /* Warna garis transparan */
    margin-top: 10px; /* Jarak antara teks dan garis */
}
                            </style>
    <a href="hapus.php?no=<?=$post['no']?>" onclick="return confirm('Apakah Anda yakin ingin menghapus ini?')"><button class="btn btn-danger"><i class="fa fa-trash-can" style="font-size:20px"></i></button></a>
       <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?= $post['no'] ?>"><span class="fa fa-edit"></span></button>
  </div>
</div>
  </div>
        </div>
       
        <!-- modal edit> -->
        <div class="modal fade" id="editModal<?= $post['no'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
            <h3 class="modal-title" id="staticBackdropLabel">Edit Postingan <?=$post['caption']?></h3><br>
            <h1 class="modal-title fs-5" id="editModal"></h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>   
            </div><div class="modal-body">
            <form action="proses_edit.php" method="post" enctype="multipart/form-data">

            <input type="hidden" name="no" value="<?=$post['no']?>">
        <input type="hidden" name="foto_lama" value="<?=$post['foto']?>">

                        <div class="form-group">
                        <label for="">Gambar</label><br>
        <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" ><br><br>
        <img src="images/<?= $post['foto'] ?>" width="100" alt="" ><br>
        
                        </div>

                        <div class="form-group">
                            <label for="caption">Judul</label>
                            <input type="text" class="form-control" id="caption" name="caption" autocomplete="off" value="<?=$post['caption']?>" required>
                        </div>

                        <div class="form-group">
                            <label for="lokasi">Lokasi</label>
                            <input type="text" class="form-control" id="lokasi" name="lokasi" autocomplete="off" value="<?=$post['lokasi']?>" required>
                        </div><br>
                      
                        <button type="submit" class="btn btn-primary" name="update">Edit</button>
                    </form>
        </div></div>
        </div>
        </div>    
        <?php } ?>
        </div>
       

<!-- Modal -->
<form action="proses_tambah.php" method="post" enctype="multipart/form-data">
<div class="modal fade" id="modalTambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Tambah Data Sepatu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
     
        <label for="">Foto</label><br>
        <input type="file" name="foto" id="" required><br>
        <label for="">Caption</label><br>
        <input type="text" name="caption" id="" autocomplete="off"><br>
        <label for="">Lokasi</label><br>
        <input type="text" name="lokasi" id="" autocomplete="off"><br><br>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-success" value="Simpan" name="simpan">
          
      </div>
    </div>
  </div>
</div>
</form>

    </div>
</div>
</center>
</body>
</html>