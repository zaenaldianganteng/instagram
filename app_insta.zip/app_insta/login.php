<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="bootstrap.min.css">
<link rel="stylesheet" href="login.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <title>Zaenal Shoes</title>
    <link rel="icon" href="zaenaldian.png">
</head>
<script src="https://code.jquery.com/jquery-2.1.0.min.js" ></script>
<body>
 <form action="proses_login.php" method="post">
<div id="formWrapper">
<div id="form">
<div class="logo">
<!-- Just an image -->

  <a class="navbar-brand" href="#">
    <img src="zaenalgg.png" width="200" height="50" alt="">
  </a>
</nav>
</div>
		<div class="form-item">
			<label for="">Username</label>
			<input type="username" name="username" id="" class="form-style" autocomplete="off"/>
		</div>
		<div class="form-item">
			<label for="">Password</label>
			<input type="password" name="password" id="" class="form-style" />
		</div>
		<div class="form-item">
		<input type="submit" class="login pull-right" value="Log In">
		<div class="clear-fix"></div>
		</div>
</div>
</div>
</form>
</body>
</html>
